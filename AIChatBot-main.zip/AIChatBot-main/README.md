# AIChatBot

## Follow the steps to chat with your own ChatBot

### Frontend

```
cd frontend
npm install --legacy-peer-deps
npm uninstall typescript
npm install typescript@3.9.10
npm uninstall react-scripts
npm install react-scripts@5.0.1
npm install
export NODE_OPTIONS=--openssl-legacy-provider`
npm start
```

### Backend (chabot)
```
cd chatbot
npm install
npm run dev
```