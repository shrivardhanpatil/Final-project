import React from "react";

import './App.css';
import QNAComponent from "./Pages/QNAComponent.tsx"

function App() {
  return (
    <div className="App">
      <QNAComponent />
    </div>
  );
}

export default App;
